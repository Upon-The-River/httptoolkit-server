# 推荐迁移步骤

## Step 1：插入 addon，但不改官方核心

推荐位置二选一：

```text
C:\Users\Card\Desktop\httptoolkit-lab-addon
```

或：

```text
C:\Users\Card\Desktop\httptoolkit-server-official\external\httptoolkit-lab-addon
```

先只复制 `lab-addon/`，不要应用 `core-patches/`。

## Step 2：跑通 addon health

```powershell
cd external\httptoolkit-lab-addon
npm install
npm run typecheck
npm run start
curl http://127.0.0.1:45457/health
```

## Step 3：迁移独立模块

先整理这些文件的 import，不要动官方核心：

```text
lab-addon/src/session/headless-health.ts
lab-addon/src/session/session-manager.ts
lab-addon/src/export/live-exporter.ts
lab-addon/src/android/android-network-safety.ts
lab-addon/src/qidian/qidian-traffic-matcher.ts
```

## Step 4：迁移 route，不要复制整个 rest-api.ts

参考：

```text
core-patches/high-value-extract/src__api__rest-api.ts.patch
```

只提取这些接口的实现到 `lab-addon/src/server.ts`：

```text
/automation/session/start
/automation/session/latest
/automation/session/stop-latest
/automation/android-adb/start-headless
/automation/android-adb/stop-headless
/automation/android-adb/recover-headless
/automation/android-adb/rescue-network
/automation/health
/export/stream
```

## Step 5：拆 ADB workflow

参考：

```text
core-patches/high-value-extract/src__interceptors__android__adb-commands.ts.patch
```

不要把整个 `adb-commands.ts` 迁入官方核心。目标是：

```text
底层 ADB primitive -> lab-addon/src/android/adb-client.ts
高层网络恢复流程 -> lab-addon/src/android/android-network-safety.ts
headless 启停流程 -> lab-addon/src/android/android-headless-service.ts
```

## Step 6：最后才判断是否需要 core hook

如果 live export 或 session manager 必须依赖 HTTP Toolkit 内部事件，才考虑在官方核心加极薄 hook。

hook 原则：

```text
核心只转发事件，不承载业务逻辑。
Qidian/Android/export 逻辑仍留在 addon。
```
