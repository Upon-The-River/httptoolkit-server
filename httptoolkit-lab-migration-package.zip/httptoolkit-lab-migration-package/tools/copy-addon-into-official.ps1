param(
    [Parameter(Mandatory=$true)]
    [string]$OfficialRoot,
    [string]$TargetRelativePath = "external\httptoolkit-lab-addon"
)

$ErrorActionPreference = "Stop"

$PackageRoot = Split-Path $PSScriptRoot -Parent
$Source = Join-Path $PackageRoot "lab-addon"
$Target = Join-Path $OfficialRoot $TargetRelativePath

if (-not (Test-Path $Source)) {
    throw "Source addon not found: $Source"
}

if (-not (Test-Path $OfficialRoot)) {
    throw "Official root not found: $OfficialRoot"
}

New-Item -ItemType Directory -Force -Path (Split-Path $Target -Parent) | Out-Null

if (Test-Path $Target) {
    throw "Target already exists: $Target. Rename or delete it manually before copying."
}

Copy-Item $Source $Target -Recurse -Force

Write-Host "Copied addon to: $Target"
Write-Host "No official core files were modified."
