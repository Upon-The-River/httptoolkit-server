# 有价值改动清单

## 必须保留，优先迁移到 addon

1. Android headless 启停/恢复
   - 来源：`src/api/rest-api.ts`, `src/automation/headless-health.ts`, `scripts/stop-headless.ps1`, `scripts/recover-headless.ps1`
   - 价值：让 Android + HTTP Toolkit headless 可以被外部控制、检查、恢复。
   - 迁移目标：`lab-addon/src/server.ts`, `lab-addon/src/session/headless-health.ts`, `lab-addon/scripts/android/`

2. Android 网络安全与恢复
   - 来源：`src/interceptors/android/android-network-safety.ts`, `src/interceptors/android/adb-commands.ts`, Android 网络脚本。
   - 价值：检查/恢复 proxy、private DNS、VPN、HTTP 连通性，防止实验机网络被污染。
   - 迁移目标：`lab-addon/src/android/`, `lab-addon/scripts/android/`

3. Session 状态与目标流量判断
   - 来源：`src/automation/session-manager.ts`
   - 价值：判断是否真的有业务流量进入代理，而不是只看进程是否启动。
   - 迁移目标：`lab-addon/src/session/session-manager.ts`
   - 注意：后续要确认官方接口是否能提供足够 session/export 数据；不够时再做极薄 hook。

4. Live export
   - 来源：`src/export/live-exporter.ts`, `config/live-export-targets.json`
   - 价值：把命中流量保存为 `session_hits.jsonl` 和 payload 文件，是后续 DataBaseScript 消费的关键数据面。
   - 迁移目标：`lab-addon/src/export/live-exporter.ts`, `lab-addon/config/live-export-targets.json`
   - 注意：如果官方包没有暴露实时 response 事件，可能需要最小 event bridge。

5. Qidian 诊断与 matcher
   - 来源：`scripts/check-qidian-circle-index.ps1`, `docs/qidian/QIDIAN_CIRCLE_INDEX_DIAGNOSTIC.md`
   - 价值：Qidian 入口诊断、circleIndex 识别、目标流量规则配置化。
   - 迁移目标：`lab-addon/src/qidian/`, `lab-addon/scripts/qidian/`

## 保留为脚本/文档资产

- `scripts/doctor-phone-network.ps1`
- `scripts/rescue-phone-network.ps1`
- `scripts/hard-reset-android-lab-device.ps1`
- `scripts/run-server.ps1`
- `docs/android/ANDROID_HEADLESS_NETWORK_SAFETY.md`
- `docs/android/ANDROID_RECOVERY_PLAYBOOK.md`
- `docs/qidian/QIDIAN_CIRCLE_INDEX_DIAGNOSTIC.md`

## 只做 patch 归档，默认不应用

- Node22/Windows runtime：`bin/run`, `bin/run.cmd`, `package.json`, `.nvmrc`
- fs rimraf 兼容：`src/util/fs.ts`
- shutdown 顺序变更：`src/shutdown.ts`
- HTTP trailers fallback：`src/client/http-client.ts`
- Android interceptor 入口变更：`src/interceptors/android/android-adb-interceptor.ts`

原则：能外接就外接；必须改核心时，只做极薄 shim，不迁移大块业务逻辑。
