# HTTP Toolkit Lab 迁移材料包

这个包用于把当前工作 fork 里的有价值改动提取出来，逐步迁移到官方 HTTP Toolkit 包旁边或内部的外接层。

目标不是直接覆盖官方包，而是：

```text
官方 HTTP Toolkit = 干净抓包底座
lab-addon = Android/headless/Qidian/live-export 实验层
core-patches = 仅供人工评估的核心补丁归档
```

## 目录说明

```text
lab-addon/                         可迁移外接包骨架与功能资产
core-patches/high-value-extract/   从核心大文件提取能力时参考的 diff
core-patches/runtime-compat/       Node22/Windows/fs 等兼容补丁，默认不要应用
core-patches/manual-review/        需要人工判断的核心行为变更
inventory/                         当前包相对官方包的文件清单差异
codex-prompts/                     给 Codex 的分阶段迁移指令
tools/                             辅助复制脚本
MIGRATION_MANIFEST.json            机器可读资产清单
VALUE_ASSESSMENT.md                功能价值判断
MIGRATION_STEPS.md                 推荐迁移步骤
```

## 推荐使用方式

1. 把官方包解压成 `httptoolkit-server-official`。
2. 不要直接应用 `core-patches/`。
3. 先把 `lab-addon/` 放到官方包旁边，或放进官方包根目录下的 `external/httptoolkit-lab-addon/`。
4. 先跑通 `lab-addon` 的 `/health`。
5. 再逐步迁移 `rest-api.ts` 里的 automation route 到 `lab-addon/src/server.ts`。
6. 最后才判断是否需要极薄 core hook。

## 不要做的事

- 不要把当前工作 fork 的 `rest-api.ts` 直接覆盖官方文件。
- 不要把当前工作 fork 的 `adb-commands.ts` 直接覆盖官方文件。
- 不要直接应用 `package.json` 或 `bin/run` patch。
- 不要把 Qidian 规则重新塞进通用 session/core 文件。
